﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { FrontPageComponent } from './app.frontpagecomponent';
import { ProgrammingCategoryComponent} from './app.programmingcategorycomponent';
import { BookListingComponent} from './app.booklistingcomponent';

@NgModule({
    imports: [
        BrowserModule
        
    ],
    declarations: [
        AppComponent,FrontPageComponent,ProgrammingCategoryComponent,BookListingComponent
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }