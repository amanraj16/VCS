import { Component } from "@angular/core";

@Component({
selector:'<emp-component></emp-component>',
templateUrl:'./app.employeecomponent.html'
})
export class AppEmpComponent
{
empId:number=101;
empName:string="Aman";
empSalary:number=50000;
}