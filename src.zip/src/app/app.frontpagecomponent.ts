import { Component } from "@angular/core";

@Component({
    selector: 'front-page',
    templateUrl: './app.frontpagecomponent.html'
})
export class FrontPageComponent{}