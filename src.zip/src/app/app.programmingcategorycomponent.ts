import { Component } from "@angular/core";

@Component({
    selector: 'programming-category',
    templateUrl: './app.programmingcategorycomponent.html'
})
export class ProgrammingCategoryComponent{}